/*
 * main.j
 * SmartFoldersDemo
 *
 * No main cib: CPApplicationMain instantiates CPApplicationDelegateClass
 * (AppController) from Info.plist.
 */

@import <Foundation/Foundation.j>
@import <AppKit/AppKit.j>

@import "AppController.j"

function main(args, namedArgs)
{
    CPApplicationMain(args, namedArgs);
}
